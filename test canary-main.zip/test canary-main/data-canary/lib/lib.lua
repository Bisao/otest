-- Core API functions implemented in Lua
dofile(DATA_DIRECTORY.. '/lib/core/load.lua')

-- Tables library
dofile(DATA_DIRECTORY.. '/lib/tables/load.lua')
