dofile(DATA_DIRECTORY.. '/lib/core/storages.lua')
dofile(DATA_DIRECTORY.. '/lib/core/constants.lua')
dofile(DATA_DIRECTORY.. '/lib/core/quests.lua')
