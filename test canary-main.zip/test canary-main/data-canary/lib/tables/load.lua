dofile(DATA_DIRECTORY.. '/lib/tables/vocation.lua')
dofile(DATA_DIRECTORY.. '/lib/tables/door.lua')
dofile(DATA_DIRECTORY.. '/lib/tables/npc_spells.lua')
dofile(DATA_DIRECTORY.. '/lib/tables/window.lua')
