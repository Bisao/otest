-- return true = There are others migrations file
-- return false = This is the last migration file
function onUpdateDatabase()
    return false
end
